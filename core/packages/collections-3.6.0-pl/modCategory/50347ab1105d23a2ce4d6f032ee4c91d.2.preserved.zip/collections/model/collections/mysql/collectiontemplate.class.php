<?php
/**
 * @package collections
 */
require_once(strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/collectiontemplate.class.php');

class CollectionTemplate_mysql extends CollectionTemplate
{
}
