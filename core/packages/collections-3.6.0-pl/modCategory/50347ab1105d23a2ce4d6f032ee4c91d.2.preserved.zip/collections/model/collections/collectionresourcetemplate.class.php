<?php

/**
 * @property int $collection_template
 * @property int $resource_template
 *
 * @property CollectionTemplate $CollectionTemplate
 * @property modTemplate $ResourceTemplate
 *
 * @package collections
 */
class CollectionResourceTemplate extends xPDOObject
{
}
