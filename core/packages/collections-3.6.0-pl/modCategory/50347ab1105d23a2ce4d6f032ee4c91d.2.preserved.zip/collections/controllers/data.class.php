<?php

/**
 * Loads the collection data page
 *
 * @package collections
 * @subpackage controllers
 */
class CollectionContainerDataManagerController extends ResourceDataManagerController
{
}
