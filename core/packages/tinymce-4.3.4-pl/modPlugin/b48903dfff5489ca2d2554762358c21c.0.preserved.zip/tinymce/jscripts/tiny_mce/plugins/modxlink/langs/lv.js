tinyMCE.addI18n('lv.modxlink',{
    link_desc:"Insert/edit link"
});