tinyMCE.addI18n('sv.modxlink',{
    link_desc:"Insert/edit link"
});